<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Management</title>
    <!-- Bootstrap files -->
    <link rel="stylesheet" href="bootstrap/css//bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- External CSS file -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger">
        <a class="navbar-brand" href="index.php">Blood Bank Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin/login.php">Admin</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="donor/login.php">Donor</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="patient/login.php">Patient</a>
            </li>
            </ul>
        </div>
    </nav>
<!-- Main content -->
<div class="container-fluid" style="margin:50px;">
    <div class="row container" style="text-align: justify;">
        <div class="col-md-8 mx-auto content-left">
            <h4>What is Blood Bank Management System?</h4>
            <p>
            A Blood Bank Management System is a comprehensive software solution designed to streamline and enhance the operations of blood banks and blood donation centers. This system plays a pivotal role in maintaining the critical supply and demand balance of blood and blood products, ensuring efficient collection, testing, storage, and distribution of blood units to meet medical needs.

At its core, the system digitizes and automates various processes involved in blood bank management. It allows for the easy recording and tracking of blood donations, donor information, and blood inventory. When a person donates blood, their details are recorded in the system, and the blood type is tested and categorized for suitability.

The software helps manage the lifecycle of blood units, from collection to storage duration tracking, reducing the chances of wastage and ensuring that expired units are appropriately discarded. Additionally, the system aids in managing the compatibility of blood types, enabling quick retrieval of suitable blood units for patients in need, particularly during emergencies or surgeries.

Blood Bank Management Systems also facilitate communication and coordination among various stakeholders, including hospitals, clinics, and donors. Hospitals can place blood requests, and the system's inventory management capabilities enable quick identification and allocation of compatible blood units.
            </p>
            <button class="btn btn-danger">Read more..</button>
        </div>
        <div class="col-md-3 content-right">
            <img class="img-fluid" src="../BBMS/images/image1.jpg" height="auto" width="70%">
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-10 m-auto" style="text-align: justify;">
            <h4>Know More About Blood Bank Management System</h4>
            <p>
            The software helps manage the lifecycle of blood units, from collection to storage duration tracking, reducing the chances of wastage and ensuring that expired units are appropriately discarded. Additionally, the system aids in managing the compatibility of blood types, enabling quick retrieval of suitable blood units for patients in need, particularly during emergencies or surgeries.

Blood Bank Management Systems also facilitate communication and coordination among various stakeholders, including hospitals, clinics, and donors. Hospitals can place blood requests, and the system's inventory management capabilities enable quick identification and allocation of compatible blood units.
            </p>
            <p>
            Furthermore, these systems improve the traceability and reporting of blood-related data, which is crucial for regulatory compliance and quality control. They assist in generating accurate reports for audits, tracking donor trends, and ensuring that the blood bank operates in accordance with medical standards and guidelines.
            </p>
        </div>
    </div>
</div>
<div class="container-fluid" style="margin-bottom: 5%;">
    <div class="row">
        <div class="col-10  m-auto">
        <h4>Our centers?</h4>
        <div class="card container">
            <h4>Jaipur</h4>
            <hr>
            <p>Often referred to as the "Pink City," Jaipur is the capital of Rajasthan. It's renowned for its stunning palaces, forts, and vibrant markets. The city's architecture and culture reflect the royal heritage.</p>
        </div>
        <div class="card">
            <h4>Delhi</h4>
            <hr>
            <p>The capital city of India, Delhi is a blend of historical heritage and modernity. It's home to iconic landmarks like the Red Fort and India Gate, and it showcases a mix of cultures and traditions.</p>
        </div>
        <div class="card">
            <h4>Patna</h4>
            <hr>
            <p>Situated in the eastern part of India, Patna is the capital of Bihar. It has a rich history dating back to ancient times and is known for its historical monuments, religious sites, and cultural significance.</p>
        </div>
        <div class="card">
            <h4>Mumbai</h4>
            <hr>
            <p>A bustling metropolis on the western coast of India, Mumbai is known as the country's financial capital. It's famous for its vibrant nightlife, diverse culture, and the Bollywood film industry.</p>
        </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 bg-danger footer">
            &copy 2023 MCA BOIS
        </div>
    </div>
</div>
</body>
</html>